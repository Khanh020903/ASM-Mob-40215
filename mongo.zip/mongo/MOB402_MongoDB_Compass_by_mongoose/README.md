# MOB402_MongoDB_Compass_by_mongoose
Lee Manh Thai - PH27046

# READ
_List
![image](https://user-images.githubusercontent.com/97508647/228509190-f88f0792-a055-4e87-9f44-3bb6095636c9.png)
![image](https://user-images.githubusercontent.com/97508647/228509268-25fc67c8-a301-4ed8-9fb0-f994a815ee2d.png)
_One Item
![image](https://user-images.githubusercontent.com/97508647/228505977-e372559e-d672-463d-86ce-fd93dd2db7a6.png)

# CREATE
![image](https://user-images.githubusercontent.com/97508647/228509507-ad926232-2b77-42ca-b51f-4e684e6a4cd5.png)
![image](https://user-images.githubusercontent.com/97508647/228509574-965bc6b5-d43b-44de-8d8a-14aefc3e8857.png)

# UPDATE
![image](https://user-images.githubusercontent.com/97508647/228509659-a17f7fe7-db77-4d4a-8c29-d546384dfac5.png)
![image](https://user-images.githubusercontent.com/97508647/228509720-966aaafb-12bb-46d9-b372-166aa655ef1d.png)

# DELETE
![image](https://user-images.githubusercontent.com/97508647/228509783-bd9e14ee-0003-4a0a-b18b-50aa86e3671f.png)
![image](https://user-images.githubusercontent.com/97508647/228509819-449bd1ef-721d-479f-827f-2efebcf7f730.png)

# FIND
![image](https://user-images.githubusercontent.com/97508647/228509976-481bac43-1db0-4e53-b314-733600f7a01e.png)
![image](https://user-images.githubusercontent.com/97508647/228510019-2510b1c3-3adb-4f01-af23-3f01d7d927d3.png)


